package com.placement.model;

import org.bson.Document;
import org.bson.types.ObjectId;

/**
 * Model class representing a daily placement preparation record.
 */
public class StudyRecord {

    private ObjectId id;
    private String date;        // Format: YYYY-MM-DD
    private String topic;       // e.g., "Arrays", "Dynamic Programming"
    private int questionsSolved;
    private String platform;    // e.g., "LeetCode", "CodeChef"
    private double studyHours;

    // ─── Constructors ────────────────────────────────────────────────────────

    public StudyRecord() {}

    public StudyRecord(String date, String topic, int questionsSolved,
                       String platform, double studyHours) {
        this.date = date;
        this.topic = topic;
        this.questionsSolved = questionsSolved;
        this.platform = platform;
        this.studyHours = studyHours;
    }

    // ─── Convert to MongoDB Document ─────────────────────────────────────────

    public Document toDocument() {
        Document doc = new Document()
                .append("date", this.date)
                .append("topic", this.topic)
                .append("questionsSolved", this.questionsSolved)
                .append("platform", this.platform)
                .append("studyHours", this.studyHours);
        if (this.id != null) {
            doc.append("_id", this.id);
        }
        return doc;
    }

    // ─── Build from MongoDB Document ─────────────────────────────────────────

    public static StudyRecord fromDocument(Document doc) {
        StudyRecord record = new StudyRecord();
        record.setId(doc.getObjectId("_id"));
        record.setDate(doc.getString("date"));
        record.setTopic(doc.getString("topic"));
        record.setQuestionsSolved(doc.getInteger("questionsSolved", 0));
        record.setPlatform(doc.getString("platform"));
        Object hours = doc.get("studyHours");
        if (hours instanceof Double) {
            record.setStudyHours((Double) hours);
        } else if (hours instanceof Integer) {
            record.setStudyHours(((Integer) hours).doubleValue());
        }
        return record;
    }

    // ─── Display ──────────────────────────────────────────────────────────────

    @Override
    public String toString() {
        return String.format(
            "  ID       : %s%n" +
            "  Date     : %s%n" +
            "  Topic    : %s%n" +
            "  Platform : %s%n" +
            "  Questions: %d%n" +
            "  Hours    : %.1f",
            id != null ? id.toHexString() : "N/A",
            date, topic, platform, questionsSolved, studyHours
        );
    }

    // ─── Getters & Setters ───────────────────────────────────────────────────

    public ObjectId getId() { return id; }
    public void setId(ObjectId id) { this.id = id; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }

    public int getQuestionsSolved() { return questionsSolved; }
    public void setQuestionsSolved(int questionsSolved) { this.questionsSolved = questionsSolved; }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public double getStudyHours() { return studyHours; }
    public void setStudyHours(double studyHours) { this.studyHours = studyHours; }
}
