package com.placement;

import com.placement.model.StudyRecord;
import com.placement.service.StudyRecordService;
import com.placement.util.MongoConnection;
import org.bson.Document;

import java.util.List;
import java.util.Scanner;

/**
 * ╔══════════════════════════════════════════════════════╗
 *  Placement Preparation Tracker – Console Application
 *  Backend : Java 11  |  Database : MongoDB
 * ╚══════════════════════════════════════════════════════╝
 */
public class Main {

    private static final StudyRecordService service = new StudyRecordService();
    private static final Scanner scanner = new Scanner(System.in);

    // ANSI colour codes for a nicer console look
    private static final String RESET  = "\u001B[0m";
    private static final String CYAN   = "\u001B[36m";
    private static final String GREEN  = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String RED    = "\u001B[31m";
    private static final String BOLD   = "\u001B[1m";

    public static void main(String[] args) {
        printBanner();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> addRecord();
                case "2" -> viewAllRecords();
                case "3" -> searchRecords();
                case "4" -> updateRecord();
                case "5" -> deleteRecord();
                case "6" -> generateProgressReport();
                case "0" -> running = false;
                default  -> printError("Invalid option. Please enter 0-6.");
            }
        }
        System.out.println(CYAN + "\n  Goodbye! Keep grinding. 💪" + RESET);
        MongoConnection.close();
        scanner.close();
    }

    // ─── BANNER ──────────────────────────────────────────────────────────────

    private static void printBanner() {
        System.out.println(CYAN + BOLD);
        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║      PLACEMENT PREPARATION TRACKER                  ║");
        System.out.println("║      Java + MongoDB   |   Console Application       ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println(RESET);
    }

    // ─── MENU ─────────────────────────────────────────────────────────────────

    private static void printMenu() {
        System.out.println(BOLD + CYAN + "\n  ┌─── MAIN MENU ─────────────────────────┐" + RESET);
        System.out.println("  │  1. Add Daily Record                  │");
        System.out.println("  │  2. View All Records                  │");
        System.out.println("  │  3. Search Records                    │");
        System.out.println("  │  4. Update Record                     │");
        System.out.println("  │  5. Delete Record                     │");
        System.out.println("  │  6. Generate Progress Report          │");
        System.out.println("  │  0. Exit                              │");
        System.out.println(BOLD + CYAN + "  └───────────────────────────────────────┘" + RESET);
        System.out.print(YELLOW + "  Enter your choice: " + RESET);
    }

    // ─── 1. ADD RECORD ────────────────────────────────────────────────────────

    private static void addRecord() {
        printSectionHeader("ADD DAILY RECORD");
        try {
            System.out.print("  Date (YYYY-MM-DD)   : ");
            String date = scanner.nextLine().trim();

            System.out.print("  Topic studied       : ");
            String topic = scanner.nextLine().trim();

            System.out.print("  Questions solved    : ");
            int questions = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("  Platform            : ");
            String platform = scanner.nextLine().trim();

            System.out.print("  Study hours         : ");
            double hours = Double.parseDouble(scanner.nextLine().trim());

            service.addRecord(date, topic, questions, platform, hours);
            printSuccess("Record added successfully!");

        } catch (NumberFormatException e) {
            printError("Invalid number format. Please enter valid numeric values.");
        } catch (IllegalArgumentException e) {
            printError(e.getMessage());
        }
    }

    // ─── 2. VIEW ALL RECORDS ─────────────────────────────────────────────────

    private static void viewAllRecords() {
        printSectionHeader("ALL RECORDS  (sorted by date, newest first)");
        List<StudyRecord> records = service.getAllRecords();
        if (records.isEmpty()) {
            printWarning("No records found. Start by adding a record!");
            return;
        }
        System.out.println("  Total records: " + GREEN + records.size() + RESET);
        printDivider();
        for (int i = 0; i < records.size(); i++) {
            System.out.println(CYAN + "  Record #" + (i + 1) + RESET);
            System.out.println(records.get(i));
            printDivider();
        }
    }

    // ─── 3. SEARCH RECORDS ───────────────────────────────────────────────────

    private static void searchRecords() {
        printSectionHeader("SEARCH RECORDS");
        System.out.println("  1. Search by Date");
        System.out.println("  2. Search by Topic");
        System.out.println("  3. Search by Platform");
        System.out.print(YELLOW + "  Choose search type: " + RESET);

        String choice = scanner.nextLine().trim();
        List<StudyRecord> results;
        String searchType;

        switch (choice) {
            case "1" -> {
                System.out.print("  Enter date (YYYY-MM-DD): ");
                String date = scanner.nextLine().trim();
                results = service.searchByDate(date);
                searchType = "date = " + date;
            }
            case "2" -> {
                System.out.print("  Enter topic keyword: ");
                String topic = scanner.nextLine().trim();
                results = service.searchByTopic(topic);
                searchType = "topic containing '" + topic + "'";
            }
            case "3" -> {
                System.out.print("  Enter platform name: ");
                String platform = scanner.nextLine().trim();
                results = service.searchByPlatform(platform);
                searchType = "platform = " + platform;
            }
            default -> {
                printError("Invalid search option.");
                return;
            }
        }

        System.out.println(GREEN + "\n  Found " + results.size() + " record(s) for " + searchType + RESET);
        printDivider();
        if (results.isEmpty()) {
            printWarning("No matching records found.");
        } else {
            for (int i = 0; i < results.size(); i++) {
                System.out.println(CYAN + "  Result #" + (i + 1) + RESET);
                System.out.println(results.get(i));
                printDivider();
            }
        }
    }

    // ─── 4. UPDATE RECORD ────────────────────────────────────────────────────

    private static void updateRecord() {
        printSectionHeader("UPDATE RECORD");
        System.out.print("  Enter Record ID to update: ");
        String id = scanner.nextLine().trim();

        StudyRecord existing = service.getById(id);
        if (existing == null) {
            printError("Record not found with ID: " + id);
            return;
        }

        System.out.println(GREEN + "\n  Current record:" + RESET);
        System.out.println(existing);
        System.out.println(YELLOW + "\n  Press ENTER to keep current value, or type new value." + RESET);

        try {
            System.out.print("  New topic [" + existing.getTopic() + "]: ");
            String topicInput = scanner.nextLine().trim();
            String newTopic = topicInput.isEmpty() ? null : topicInput;

            System.out.print("  New questions solved [" + existing.getQuestionsSolved() + "]: ");
            String qInput = scanner.nextLine().trim();
            Integer newQuestions = qInput.isEmpty() ? null : Integer.parseInt(qInput);

            System.out.print("  New study hours [" + existing.getStudyHours() + "]: ");
            String hInput = scanner.nextLine().trim();
            Double newHours = hInput.isEmpty() ? null : Double.parseDouble(hInput);

            System.out.print("  New platform [" + existing.getPlatform() + "]: ");
            String pInput = scanner.nextLine().trim();
            String newPlatform = pInput.isEmpty() ? null : pInput;

            boolean updated = service.updateRecord(id, newQuestions, newHours, newTopic, newPlatform);
            if (updated) {
                printSuccess("Record updated successfully!");
            } else {
                printWarning("No changes were made.");
            }

        } catch (NumberFormatException e) {
            printError("Invalid number format entered.");
        }
    }

    // ─── 5. DELETE RECORD ────────────────────────────────────────────────────

    private static void deleteRecord() {
        printSectionHeader("DELETE RECORD");
        System.out.print("  Enter Record ID to delete: ");
        String id = scanner.nextLine().trim();

        StudyRecord existing = service.getById(id);
        if (existing == null) {
            printError("Record not found with ID: " + id);
            return;
        }

        System.out.println(RED + "\n  Record to be deleted:" + RESET);
        System.out.println(existing);
        System.out.print(YELLOW + "\n  Confirm deletion? (yes/no): " + RESET);
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("yes") || confirm.equals("y")) {
            boolean deleted = service.deleteRecord(id);
            if (deleted) {
                printSuccess("Record deleted successfully!");
            } else {
                printError("Failed to delete record.");
            }
        } else {
            printWarning("Deletion cancelled.");
        }
    }

    // ─── 6. PROGRESS REPORT ──────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private static void generateProgressReport() {
        printSectionHeader("PROGRESS REPORT");

        long totalRecords = service.getTotalRecords();
        if (totalRecords == 0) {
            printWarning("No records found. Add some study records first!");
            return;
        }

        Document report = service.getProgressReport();

        int    totalQ    = report.getInteger("totalQuestions", 0);
        Object hoursObj  = report.get("totalHours");
        double totalH    = (hoursObj instanceof Double) ? (Double) hoursObj
                         : (hoursObj instanceof Integer) ? ((Integer) hoursObj).doubleValue() : 0.0;
        String topTopic  = report.getString("topTopic");
        List<Document> platformStats = (List<Document>) report.get("platformStats");

        System.out.println(BOLD + CYAN);
        System.out.println("  ┌─────────────────────────────────────────────┐");
        System.out.printf ("  │  %-20s : %-22d│%n", "Total Records",    totalRecords);
        System.out.printf ("  │  %-20s : %-22d│%n", "Total Questions",  totalQ);
        System.out.printf ("  │  %-20s : %-22s│%n", "Total Study Hours", String.format("%.1f hrs", totalH));
        System.out.printf ("  │  %-20s : %-22s│%n", "Most Studied Topic", topTopic);
        System.out.println("  └─────────────────────────────────────────────┘");
        System.out.println(RESET);

        if (platformStats != null && !platformStats.isEmpty()) {
            System.out.println(BOLD + CYAN + "  Platform-wise Breakdown:" + RESET);
            System.out.println(CYAN + "  ┌──────────────────┬───────────┬──────────┬──────────┐");
            System.out.println(       "  │ Platform         │ Questions │ Hours    │ Sessions │");
            System.out.println(       "  ├──────────────────┼───────────┼──────────┼──────────┤" + RESET);

            for (Document stat : platformStats) {
                String platform  = stat.getString("_id");
                int    questions = stat.getInteger("questions", 0);
                Object hObj      = stat.get("hours");
                double hours     = (hObj instanceof Double) ? (Double) hObj
                                 : (hObj instanceof Integer) ? ((Integer) hObj).doubleValue() : 0.0;
                int    sessions  = stat.getInteger("sessions", 0);

                System.out.printf(CYAN + "  │ %-16s │ %-9d │ %-8.1f │ %-8d │%n" + RESET,
                        platform, questions, hours, sessions);
            }
            System.out.println(CYAN + "  └──────────────────┴───────────┴──────────┴──────────┘" + RESET);
        }
    }

    // ─── UTILITY HELPERS ─────────────────────────────────────────────────────

    private static void printSectionHeader(String title) {
        System.out.println(BOLD + CYAN + "\n  ═══ " + title + " ═══" + RESET);
    }

    private static void printDivider() {
        System.out.println("  ─────────────────────────────────────────────");
    }

    private static void printSuccess(String msg) {
        System.out.println(GREEN + "\n  ✔  " + msg + RESET);
    }

    private static void printError(String msg) {
        System.out.println(RED + "\n  ✘  ERROR: " + msg + RESET);
    }

    private static void printWarning(String msg) {
        System.out.println(YELLOW + "\n  ⚠  " + msg + RESET);
    }
}
