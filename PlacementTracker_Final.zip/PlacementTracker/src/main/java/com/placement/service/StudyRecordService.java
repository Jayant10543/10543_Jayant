package com.placement.service;

import com.placement.model.StudyRecord;
import com.placement.repository.StudyRecordRepository;
import org.bson.Document;

import java.util.List;

/**
 * Service layer: validates input and delegates to the repository.
 */
public class StudyRecordService {

    private final StudyRecordRepository repository = new StudyRecordRepository();

    // ─── Add ─────────────────────────────────────────────────────────────────

    public void addRecord(String date, String topic, int questionsSolved,
                          String platform, double studyHours) {
        if (date.isBlank() || topic.isBlank() || platform.isBlank()) {
            throw new IllegalArgumentException("Date, topic, and platform cannot be empty.");
        }
        if (questionsSolved < 0) {
            throw new IllegalArgumentException("Questions solved cannot be negative.");
        }
        if (studyHours < 0) {
            throw new IllegalArgumentException("Study hours cannot be negative.");
        }
        StudyRecord record = new StudyRecord(date, topic, questionsSolved, platform, studyHours);
        repository.insertRecord(record);
    }

    // ─── View All ────────────────────────────────────────────────────────────

    public List<StudyRecord> getAllRecords() {
        return repository.findAll();
    }

    // ─── Search ──────────────────────────────────────────────────────────────

    public List<StudyRecord> searchByDate(String date) {
        return repository.findByDate(date);
    }

    public List<StudyRecord> searchByTopic(String topic) {
        return repository.findByTopic(topic);
    }

    public List<StudyRecord> searchByPlatform(String platform) {
        return repository.findByPlatform(platform);
    }

    // ─── Update ──────────────────────────────────────────────────────────────

    public boolean updateRecord(String id, Integer questionsSolved, Double studyHours,
                                String topic, String platform) {
        return repository.updateRecord(id, questionsSolved, studyHours, topic, platform);
    }

    // ─── Delete ──────────────────────────────────────────────────────────────

    public boolean deleteRecord(String id) {
        return repository.deleteRecord(id);
    }

    // ─── Progress Report ─────────────────────────────────────────────────────

    public Document getProgressReport() {
        return repository.generateProgressReport();
    }

    // ─── Find by ID (used before update to show current state) ───────────────

    public StudyRecord getById(String id) {
        return repository.findById(id);
    }

    public long getTotalRecords() {
        return repository.countAll();
    }
}
