package com.placement.util;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

/**
 * Singleton MongoDB connection manager.
 * Edit MONGO_URI if your MongoDB runs on a different host/port,
 * or if you are using MongoDB Atlas (cloud).
 */
public class MongoConnection {

    // ── Configuration ─────────────────────────────────────────────────────────
    // Local MongoDB  →  "mongodb://localhost:27017"
    // Atlas example  →  "mongodb+srv://<user>:<pass>@cluster.mongodb.net"
    private static final String MONGO_URI = "mongodb://localhost:27017";
    private static final String DB_NAME   = "placement_tracker";

    private static MongoClient   mongoClient;
    private static MongoDatabase database;

    // Prevent instantiation
    private MongoConnection() {}

    /**
     * Returns (and lazily creates) the MongoDatabase instance.
     */
    public static MongoDatabase getDatabase() {
        if (database == null) {
            mongoClient = MongoClients.create(MONGO_URI);
            database    = mongoClient.getDatabase(DB_NAME);
        }
        return database;
    }

    /**
     * Call once on application exit to release resources cleanly.
     */
    public static void close() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("\n[INFO] MongoDB connection closed.");
        }
    }
}
