package com.placement.repository;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.placement.model.StudyRecord;
import com.placement.util.MongoConnection;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Handles all MongoDB operations for the StudyRecord collection.
 */
public class StudyRecordRepository {

    private static final String COLLECTION = "study_records";

    private MongoCollection<Document> getCollection() {
        MongoDatabase db = MongoConnection.getDatabase();
        return db.getCollection(COLLECTION);
    }

    // ─── CREATE ──────────────────────────────────────────────────────────────

    public void insertRecord(StudyRecord record) {
        getCollection().insertOne(record.toDocument());
    }

    // ─── READ – All ───────────────────────────────────────────────────────────

    public List<StudyRecord> findAll() {
        List<StudyRecord> records = new ArrayList<>();
        try (MongoCursor<Document> cursor = getCollection()
                .find()
                .sort(Sorts.descending("date"))
                .iterator()) {
            while (cursor.hasNext()) {
                records.add(StudyRecord.fromDocument(cursor.next()));
            }
        }
        return records;
    }

    // ─── READ – By ID ─────────────────────────────────────────────────────────

    public StudyRecord findById(String id) {
        try {
            ObjectId objectId = new ObjectId(id);
            Document doc = getCollection().find(Filters.eq("_id", objectId)).first();
            return doc != null ? StudyRecord.fromDocument(doc) : null;
        } catch (IllegalArgumentException e) {
            return null; // invalid ObjectId format
        }
    }

    // ─── READ – By Date ───────────────────────────────────────────────────────

    public List<StudyRecord> findByDate(String date) {
        List<StudyRecord> records = new ArrayList<>();
        try (MongoCursor<Document> cursor = getCollection()
                .find(Filters.eq("date", date))
                .iterator()) {
            while (cursor.hasNext()) {
                records.add(StudyRecord.fromDocument(cursor.next()));
            }
        }
        return records;
    }

    // ─── READ – By Topic (case-insensitive partial match) ────────────────────

    public List<StudyRecord> findByTopic(String topic) {
        List<StudyRecord> records = new ArrayList<>();
        Pattern pattern = Pattern.compile(topic, Pattern.CASE_INSENSITIVE);
        try (MongoCursor<Document> cursor = getCollection()
                .find(Filters.regex("topic", pattern))
                .iterator()) {
            while (cursor.hasNext()) {
                records.add(StudyRecord.fromDocument(cursor.next()));
            }
        }
        return records;
    }

    // ─── READ – By Platform (case-insensitive) ────────────────────────────────

    public List<StudyRecord> findByPlatform(String platform) {
        List<StudyRecord> records = new ArrayList<>();
        Pattern pattern = Pattern.compile("^" + platform + "$", Pattern.CASE_INSENSITIVE);
        try (MongoCursor<Document> cursor = getCollection()
                .find(Filters.regex("platform", pattern))
                .iterator()) {
            while (cursor.hasNext()) {
                records.add(StudyRecord.fromDocument(cursor.next()));
            }
        }
        return records;
    }

    // ─── UPDATE ───────────────────────────────────────────────────────────────

    public boolean updateRecord(String id, Integer questionsSolved, Double studyHours,
                                String topic, String platform) {
        try {
            ObjectId objectId = new ObjectId(id);
            List<Bson> updates = new ArrayList<>();

            if (questionsSolved != null) updates.add(Updates.set("questionsSolved", questionsSolved));
            if (studyHours      != null) updates.add(Updates.set("studyHours",      studyHours));
            if (topic           != null) updates.add(Updates.set("topic",           topic));
            if (platform        != null) updates.add(Updates.set("platform",        platform));

            if (updates.isEmpty()) return false;

            UpdateResult result = getCollection().updateOne(
                    Filters.eq("_id", objectId),
                    Updates.combine(updates)
            );
            return result.getModifiedCount() > 0;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // ─── DELETE ───────────────────────────────────────────────────────────────

    public boolean deleteRecord(String id) {
        try {
            ObjectId objectId = new ObjectId(id);
            DeleteResult result = getCollection().deleteOne(Filters.eq("_id", objectId));
            return result.getDeletedCount() > 0;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // ─── AGGREGATION – Progress Report ───────────────────────────────────────

    /**
     * Returns a summary document with:
     *   totalQuestions, totalHours, topTopic, platformStats[]
     */
    public Document generateProgressReport() {
        // 1. Overall totals
        List<Document> totalPipeline = Arrays.asList(
            new Document("$group", new Document("_id", null)
                .append("totalQuestions", new Document("$sum", "$questionsSolved"))
                .append("totalHours",     new Document("$sum", "$studyHours"))
            )
        );

        Document totals = null;
        try (MongoCursor<Document> c = getCollection().aggregate(totalPipeline).iterator()) {
            if (c.hasNext()) totals = c.next();
        }

        // 2. Most studied topic (by total questions solved under that topic)
        List<Document> topicPipeline = Arrays.asList(
            new Document("$group", new Document("_id", "$topic")
                .append("count", new Document("$sum", "$questionsSolved"))
            ),
            new Document("$sort",  new Document("count", -1)),
            new Document("$limit", 1)
        );

        Document topTopicDoc = null;
        try (MongoCursor<Document> c = getCollection().aggregate(topicPipeline).iterator()) {
            if (c.hasNext()) topTopicDoc = c.next();
        }

        // 3. Platform-wise stats
        List<Document> platformPipeline = Arrays.asList(
            new Document("$group", new Document("_id", "$platform")
                .append("questions", new Document("$sum", "$questionsSolved"))
                .append("hours",     new Document("$sum", "$studyHours"))
                .append("sessions",  new Document("$sum", 1))
            ),
            new Document("$sort", new Document("questions", -1))
        );

        List<Document> platformStats = new ArrayList<>();
        try (MongoCursor<Document> c = getCollection().aggregate(platformPipeline).iterator()) {
            while (c.hasNext()) platformStats.add(c.next());
        }

        // Build result document
        Document report = new Document();
        report.append("totalQuestions", totals != null ? totals.getInteger("totalQuestions", 0) : 0);
        report.append("totalHours",     totals != null ? totals.get("totalHours") : 0);
        report.append("topTopic",       topTopicDoc != null ? topTopicDoc.getString("_id") : "N/A");
        report.append("platformStats",  platformStats);
        return report;
    }

    // ─── COUNT ────────────────────────────────────────────────────────────────

    public long countAll() {
        return getCollection().countDocuments();
    }
}
