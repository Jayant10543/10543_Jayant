# 📚 Placement Preparation Tracker
**Java + MongoDB | Console-Based Application**

---

## 🗂️ Project Structure

```
PlacementTracker/
├── pom.xml
└── src/
    └── main/
        └── java/
            └── com/placement/
                ├── Main.java                          ← Entry point (Console UI)
                ├── model/
                │   └── StudyRecord.java               ← Data model
                ├── repository/
                │   └── StudyRecordRepository.java     ← MongoDB CRUD + Aggregation
                ├── service/
                │   └── StudyRecordService.java        ← Business logic
                └── util/
                    └── MongoConnection.java           ← DB connection manager
```

---

## ✅ Prerequisites

| Tool       | Version  | Download                          |
|------------|----------|-----------------------------------|
| Java JDK   | 11+      | https://adoptium.net              |
| Maven      | 3.6+     | https://maven.apache.org/download |
| MongoDB    | 6.0+     | https://www.mongodb.com/try/download/community |

---

## ⚙️ Setup & Run

### Step 1 – Start MongoDB
```bash
# Windows (if MongoDB is installed as a service)
net start MongoDB

# OR run manually
mongod --dbpath "C:\data\db"
```

### Step 2 – Build the project
```bash
cd PlacementTracker
mvn clean package -q
```
This creates `target/PlacementTracker.jar`

### Step 3 – Run the application
```bash
java -jar target/PlacementTracker.jar
```

---

## 🔌 MongoDB Atlas (Cloud) Setup

If you want to use MongoDB Atlas instead of local MongoDB:

1. Create a free cluster at https://cloud.mongodb.com
2. Get your connection string (looks like):
   `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net`
3. Open `MongoConnection.java` and replace:
```java
private static final String MONGO_URI = "mongodb://localhost:27017";
```
with:
```java
private static final String MONGO_URI = "mongodb+srv://username:password@cluster0.xxxxx.mongodb.net";
```
4. Rebuild: `mvn clean package`

---

## 📋 Features

| # | Feature             | MongoDB Operation Used           |
|---|---------------------|----------------------------------|
| 1 | Add Daily Record    | `insertOne()`                    |
| 2 | View All Records    | `find()` with sort               |
| 3 | Search by Date      | `find()` with `$eq` filter       |
| 4 | Search by Topic     | `find()` with `$regex` filter    |
| 5 | Search by Platform  | `find()` with `$regex` filter    |
| 6 | Update Record       | `updateOne()` with `$set`        |
| 7 | Delete Record       | `deleteOne()`                    |
| 8 | Progress Report     | Aggregation pipeline (`$group`, `$sort`, `$limit`) |

---

## 📦 Database Details

- **Database name:** `placement_tracker`
- **Collection:**    `study_records`
- **Document structure:**
```json
{
  "_id":             ObjectId("..."),
  "date":            "2026-06-11",
  "topic":           "Dynamic Programming",
  "questionsSolved": 12,
  "platform":        "LeetCode",
  "studyHours":      3.5
}
```

---

## 🎯 Sample Session

```
╔══════════════════════════════════════════════════════╗
║      PLACEMENT PREPARATION TRACKER                  ║
║      Java + MongoDB   |   Console Application       ║
╚══════════════════════════════════════════════════════╝

  ┌─── MAIN MENU ─────────────────────────┐
  │  1. Add Daily Record                  │
  │  2. View All Records                  │
  │  3. Search Records                    │
  │  4. Update Record                     │
  │  5. Delete Record                     │
  │  6. Generate Progress Report          │
  │  0. Exit                              │
  └───────────────────────────────────────┘
  Enter your choice: 1

  ═══ ADD DAILY RECORD ═══
  Date (YYYY-MM-DD)   : 2026-06-11
  Topic studied       : Dynamic Programming
  Questions solved    : 8
  Platform            : LeetCode
  Study hours         : 3.5

  ✔  Record added successfully!
```

---

## 👨‍💻 Technologies Used

- **Java 11** – Application logic
- **MongoDB Java Driver 4.11** – Database connectivity
- **Maven** – Build & dependency management
- **MongoDB Aggregation Pipeline** – Progress report generation
